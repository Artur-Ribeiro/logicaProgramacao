﻿namespace appativ10lista3
{
    partial class Frmanos
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblnasc = new System.Windows.Forms.Label();
            this.lblano = new System.Windows.Forms.Label();
            this.txtnasc = new System.Windows.Forms.TextBox();
            this.txtano = new System.Windows.Forms.TextBox();
            this.btncalc = new System.Windows.Forms.Button();
            this.lblresult = new System.Windows.Forms.Label();
            this.lblresult2 = new System.Windows.Forms.Label();
            this.lblresult3 = new System.Windows.Forms.Label();
            this.lblresult4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblnasc
            // 
            this.lblnasc.AutoSize = true;
            this.lblnasc.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblnasc.Location = new System.Drawing.Point(36, 24);
            this.lblnasc.Name = "lblnasc";
            this.lblnasc.Size = new System.Drawing.Size(144, 20);
            this.lblnasc.TabIndex = 0;
            this.lblnasc.Text = "ano de nascimento";
            // 
            // lblano
            // 
            this.lblano.AutoSize = true;
            this.lblano.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblano.Location = new System.Drawing.Point(37, 96);
            this.lblano.Name = "lblano";
            this.lblano.Size = new System.Drawing.Size(75, 20);
            this.lblano.TabIndex = 1;
            this.lblano.Text = "ano atual";
            // 
            // txtnasc
            // 
            this.txtnasc.Location = new System.Drawing.Point(39, 53);
            this.txtnasc.Name = "txtnasc";
            this.txtnasc.Size = new System.Drawing.Size(100, 20);
            this.txtnasc.TabIndex = 2;
            // 
            // txtano
            // 
            this.txtano.Location = new System.Drawing.Point(39, 147);
            this.txtano.Name = "txtano";
            this.txtano.Size = new System.Drawing.Size(100, 20);
            this.txtano.TabIndex = 3;
            // 
            // btncalc
            // 
            this.btncalc.Location = new System.Drawing.Point(41, 213);
            this.btncalc.Name = "btncalc";
            this.btncalc.Size = new System.Drawing.Size(75, 23);
            this.btncalc.TabIndex = 4;
            this.btncalc.Text = "calcular";
            this.btncalc.UseVisualStyleBackColor = true;
            this.btncalc.Click += new System.EventHandler(this.btncalc_Click);
            // 
            // lblresult
            // 
            this.lblresult.AutoSize = true;
            this.lblresult.Location = new System.Drawing.Point(227, 60);
            this.lblresult.Name = "lblresult";
            this.lblresult.Size = new System.Drawing.Size(0, 13);
            this.lblresult.TabIndex = 5;
            // 
            // lblresult2
            // 
            this.lblresult2.AutoSize = true;
            this.lblresult2.Location = new System.Drawing.Point(227, 83);
            this.lblresult2.Name = "lblresult2";
            this.lblresult2.Size = new System.Drawing.Size(0, 13);
            this.lblresult2.TabIndex = 6;
            // 
            // lblresult3
            // 
            this.lblresult3.AutoSize = true;
            this.lblresult3.Location = new System.Drawing.Point(227, 103);
            this.lblresult3.Name = "lblresult3";
            this.lblresult3.Size = new System.Drawing.Size(0, 13);
            this.lblresult3.TabIndex = 7;
            // 
            // lblresult4
            // 
            this.lblresult4.AutoSize = true;
            this.lblresult4.Location = new System.Drawing.Point(227, 125);
            this.lblresult4.Name = "lblresult4";
            this.lblresult4.Size = new System.Drawing.Size(0, 13);
            this.lblresult4.TabIndex = 8;
            // 
            // Frmanos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(483, 287);
            this.Controls.Add(this.lblresult4);
            this.Controls.Add(this.lblresult3);
            this.Controls.Add(this.lblresult2);
            this.Controls.Add(this.lblresult);
            this.Controls.Add(this.btncalc);
            this.Controls.Add(this.txtano);
            this.Controls.Add(this.txtnasc);
            this.Controls.Add(this.lblano);
            this.Controls.Add(this.lblnasc);
            this.Name = "Frmanos";
            this.Text = "Anos";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblnasc;
        private System.Windows.Forms.Label lblano;
        private System.Windows.Forms.TextBox txtnasc;
        private System.Windows.Forms.TextBox txtano;
        private System.Windows.Forms.Button btncalc;
        private System.Windows.Forms.Label lblresult;
        private System.Windows.Forms.Label lblresult2;
        private System.Windows.Forms.Label lblresult3;
        private System.Windows.Forms.Label lblresult4;
    }
}

