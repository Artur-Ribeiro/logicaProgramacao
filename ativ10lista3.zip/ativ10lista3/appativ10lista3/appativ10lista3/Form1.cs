﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace appativ10lista3
{
    public partial class Frmanos : Form
    {
        public Frmanos()
        {
            InitializeComponent();
        }

        private void btncalc_Click(object sender, EventArgs e)
        {
            int nasc = int.Parse(txtnasc.Text);
            int ano = int.Parse(txtano.Text);
            float result;
            float divisao = 52.14f;

            result = ano - nasc;
            lblresult.Text = ("idade: "+result);


            result = (ano - nasc) * 12;
            lblresult2.Text = ("idade em meses: "+result);

            result = (ano - nasc) * 365;
            lblresult3.Text = ("idade em dias: " + result);

            result = (ano - nasc) * divisao;
            lblresult4.Text = ("idade em semanas: " + result);
        }

    }
}
