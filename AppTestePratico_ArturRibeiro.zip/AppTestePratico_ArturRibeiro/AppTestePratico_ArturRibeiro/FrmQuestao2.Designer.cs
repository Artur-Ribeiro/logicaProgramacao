﻿namespace AppTestePratico_ArturRibeiro
{
    partial class FrmQuestao2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnl1 = new System.Windows.Forms.Panel();
            this.lblQst2 = new System.Windows.Forms.Label();
            this.lblCamsP = new System.Windows.Forms.Label();
            this.lblCamsM = new System.Windows.Forms.Label();
            this.lblCamsG = new System.Windows.Forms.Label();
            this.lblResult = new System.Windows.Forms.Label();
            this.txtCamsP = new System.Windows.Forms.TextBox();
            this.txtCamsM = new System.Windows.Forms.TextBox();
            this.txtCamsG = new System.Windows.Forms.TextBox();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.lblLegenda = new System.Windows.Forms.Label();
            this.pnl1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnl1
            // 
            this.pnl1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pnl1.Controls.Add(this.lblQst2);
            this.pnl1.Location = new System.Drawing.Point(-4, 0);
            this.pnl1.Name = "pnl1";
            this.pnl1.Size = new System.Drawing.Size(810, 128);
            this.pnl1.TabIndex = 0;
            // 
            // lblQst2
            // 
            this.lblQst2.AutoSize = true;
            this.lblQst2.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQst2.Location = new System.Drawing.Point(76, 36);
            this.lblQst2.Name = "lblQst2";
            this.lblQst2.Size = new System.Drawing.Size(195, 39);
            this.lblQst2.TabIndex = 0;
            this.lblQst2.Text = "Questão 02";
            // 
            // lblCamsP
            // 
            this.lblCamsP.AutoSize = true;
            this.lblCamsP.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCamsP.Location = new System.Drawing.Point(76, 156);
            this.lblCamsP.Name = "lblCamsP";
            this.lblCamsP.Size = new System.Drawing.Size(230, 24);
            this.lblCamsP.TabIndex = 1;
            this.lblCamsP.Text = "Quantidade de camisas P:";
            // 
            // lblCamsM
            // 
            this.lblCamsM.AutoSize = true;
            this.lblCamsM.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCamsM.Location = new System.Drawing.Point(76, 219);
            this.lblCamsM.Name = "lblCamsM";
            this.lblCamsM.Size = new System.Drawing.Size(234, 24);
            this.lblCamsM.TabIndex = 2;
            this.lblCamsM.Text = "Quantidades de camisa M:";
            // 
            // lblCamsG
            // 
            this.lblCamsG.AutoSize = true;
            this.lblCamsG.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCamsG.Location = new System.Drawing.Point(75, 286);
            this.lblCamsG.Name = "lblCamsG";
            this.lblCamsG.Size = new System.Drawing.Size(232, 24);
            this.lblCamsG.TabIndex = 3;
            this.lblCamsG.Text = "Quantidade de camisas G:";
            // 
            // lblResult
            // 
            this.lblResult.AutoSize = true;
            this.lblResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResult.Location = new System.Drawing.Point(414, 367);
            this.lblResult.Name = "lblResult";
            this.lblResult.Size = new System.Drawing.Size(39, 25);
            this.lblResult.TabIndex = 4;
            this.lblResult.Text = "R$";
            // 
            // txtCamsP
            // 
            this.txtCamsP.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCamsP.Location = new System.Drawing.Point(80, 183);
            this.txtCamsP.Name = "txtCamsP";
            this.txtCamsP.Size = new System.Drawing.Size(120, 26);
            this.txtCamsP.TabIndex = 5;
            // 
            // txtCamsM
            // 
            this.txtCamsM.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCamsM.Location = new System.Drawing.Point(80, 246);
            this.txtCamsM.Name = "txtCamsM";
            this.txtCamsM.Size = new System.Drawing.Size(120, 26);
            this.txtCamsM.TabIndex = 6;
            // 
            // txtCamsG
            // 
            this.txtCamsG.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCamsG.Location = new System.Drawing.Point(79, 313);
            this.txtCamsG.Name = "txtCamsG";
            this.txtCamsG.Size = new System.Drawing.Size(121, 26);
            this.txtCamsG.TabIndex = 7;
            // 
            // btnCalcular
            // 
            this.btnCalcular.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalcular.Location = new System.Drawing.Point(80, 367);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(108, 34);
            this.btnCalcular.TabIndex = 8;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // lblLegenda
            // 
            this.lblLegenda.AutoSize = true;
            this.lblLegenda.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLegenda.Location = new System.Drawing.Point(414, 328);
            this.lblLegenda.Name = "lblLegenda";
            this.lblLegenda.Size = new System.Drawing.Size(147, 25);
            this.lblLegenda.TabIndex = 9;
            this.lblLegenda.Text = "Valor a pagar:";
            // 
            // FrmQuestao2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(692, 450);
            this.Controls.Add(this.lblLegenda);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.txtCamsG);
            this.Controls.Add(this.txtCamsM);
            this.Controls.Add(this.txtCamsP);
            this.Controls.Add(this.lblResult);
            this.Controls.Add(this.lblCamsG);
            this.Controls.Add(this.lblCamsM);
            this.Controls.Add(this.lblCamsP);
            this.Controls.Add(this.pnl1);
            this.Name = "FrmQuestao2";
            this.Text = "FrmQuestao2";
            this.pnl1.ResumeLayout(false);
            this.pnl1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnl1;
        private System.Windows.Forms.Label lblQst2;
        private System.Windows.Forms.Label lblCamsP;
        private System.Windows.Forms.Label lblCamsM;
        private System.Windows.Forms.Label lblCamsG;
        private System.Windows.Forms.Label lblResult;
        private System.Windows.Forms.TextBox txtCamsP;
        private System.Windows.Forms.TextBox txtCamsM;
        private System.Windows.Forms.TextBox txtCamsG;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Label lblLegenda;
    }
}