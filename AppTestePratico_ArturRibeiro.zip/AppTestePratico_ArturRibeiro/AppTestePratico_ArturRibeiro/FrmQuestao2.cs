﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppTestePratico_ArturRibeiro
{
    public partial class FrmQuestao2 : Form
    {
        public FrmQuestao2()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (txtCamsP.Text == (""))
            {
                txtCamsP.Text = (0 + "");
            }
            if (txtCamsM.Text == (""))
            {
                txtCamsM.Text = (0 + "");
            }
            if (txtCamsG.Text == (""))
            {
                txtCamsG.Text = (0 + "");
            }

            int camsp = int.Parse(txtCamsP.Text);
            int camsm = int.Parse(txtCamsM.Text);
            int camsg = int.Parse(txtCamsG.Text);
            float result;

            result = camsp *12 + camsm * 14 + camsg * 22;
            lblResult.Text = ("R$" + result + ",00");
        }

    }
}
