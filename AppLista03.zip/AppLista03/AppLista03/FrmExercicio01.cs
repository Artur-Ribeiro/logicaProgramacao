﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppLista03
{
    public partial class FrmExercicio01 : Form
    {
        public FrmExercicio01()
        {
            InitializeComponent();
        }

        private void btnSoma_Click(object sender, EventArgs e)
        {
            float num1 = float.Parse(txtnum1.Text);
            float num3 = float.Parse(txtnum3.Text);
            float soma;

            soma = num1 + num3;
            lblResp1.Text = ("A soma do num1 com num3 é: " + soma);
        }

        private void btnMedia_Click(object sender, EventArgs e)
        {
            float num1 = float.Parse(txtnum1.Text);
            float num2 = float.Parse(txtnum2.Text);
            float num3 = float.Parse(txtnum3.Text);
            float media;

            media = (num1 + num2 + num3) / 3;
            lblResp2.Text = ("A media é: " + media);
        }

        private void btnPorcentagem_Click(object sender, EventArgs e)
        {
            float num1 = float.Parse(txtnum1.Text);
            float num2 = float.Parse(txtnum2.Text);
            float num3 = float.Parse(txtnum3.Text);
            float pnum1, pnum2, pnum3;

            pnum1 = num1 / (num1 + num2 + num3) * 100;
            pnum2 = num2 / (num1 + num2 + num3) * 100;
            pnum3 = num3 / (num1 + num2 + num3) * 100;
            lblResp3.Text = ("num1: " + pnum1 + "%  num2: " + pnum2 + "%  num3: " + pnum3 + "%");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtnum1.Text = String.Empty;
            txtnum2.Text = String.Empty;
            txtnum3.Text = String.Empty;
            lblResp1.Text = String.Empty;
            lblResp2.Text = String.Empty;
            lblResp3.Text = String.Empty;
        }
    }
}
