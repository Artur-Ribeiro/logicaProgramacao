﻿namespace AppLista03
{
    partial class FrmExercicio01
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtnum1 = new System.Windows.Forms.TextBox();
            this.txtnum2 = new System.Windows.Forms.TextBox();
            this.txtnum3 = new System.Windows.Forms.TextBox();
            this.lblnum1 = new System.Windows.Forms.Label();
            this.lblnum2 = new System.Windows.Forms.Label();
            this.lblnum3 = new System.Windows.Forms.Label();
            this.lblExercicio = new System.Windows.Forms.Label();
            this.btnSoma = new System.Windows.Forms.Button();
            this.btnMedia = new System.Windows.Forms.Button();
            this.btnPorcentagem = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.lblResp1 = new System.Windows.Forms.Label();
            this.lblResp2 = new System.Windows.Forms.Label();
            this.lblResp3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtnum1
            // 
            this.txtnum1.Location = new System.Drawing.Point(124, 107);
            this.txtnum1.Name = "txtnum1";
            this.txtnum1.Size = new System.Drawing.Size(100, 20);
            this.txtnum1.TabIndex = 0;
            // 
            // txtnum2
            // 
            this.txtnum2.Location = new System.Drawing.Point(124, 162);
            this.txtnum2.Name = "txtnum2";
            this.txtnum2.Size = new System.Drawing.Size(100, 20);
            this.txtnum2.TabIndex = 1;
            // 
            // txtnum3
            // 
            this.txtnum3.Location = new System.Drawing.Point(124, 217);
            this.txtnum3.Name = "txtnum3";
            this.txtnum3.Size = new System.Drawing.Size(100, 20);
            this.txtnum3.TabIndex = 2;
            // 
            // lblnum1
            // 
            this.lblnum1.AutoSize = true;
            this.lblnum1.Location = new System.Drawing.Point(59, 107);
            this.lblnum1.Name = "lblnum1";
            this.lblnum1.Size = new System.Drawing.Size(35, 13);
            this.lblnum1.TabIndex = 3;
            this.lblnum1.Text = "Num1";
            // 
            // lblnum2
            // 
            this.lblnum2.AutoSize = true;
            this.lblnum2.Location = new System.Drawing.Point(59, 162);
            this.lblnum2.Name = "lblnum2";
            this.lblnum2.Size = new System.Drawing.Size(35, 13);
            this.lblnum2.TabIndex = 4;
            this.lblnum2.Text = "Num2";
            // 
            // lblnum3
            // 
            this.lblnum3.AutoSize = true;
            this.lblnum3.Location = new System.Drawing.Point(59, 217);
            this.lblnum3.Name = "lblnum3";
            this.lblnum3.Size = new System.Drawing.Size(35, 13);
            this.lblnum3.TabIndex = 5;
            this.lblnum3.Text = "Num3";
            // 
            // lblExercicio
            // 
            this.lblExercicio.AutoSize = true;
            this.lblExercicio.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblExercicio.Location = new System.Drawing.Point(56, 34);
            this.lblExercicio.Name = "lblExercicio";
            this.lblExercicio.Size = new System.Drawing.Size(154, 31);
            this.lblExercicio.TabIndex = 6;
            this.lblExercicio.Text = "Exercicio01";
            // 
            // btnSoma
            // 
            this.btnSoma.Location = new System.Drawing.Point(62, 265);
            this.btnSoma.Name = "btnSoma";
            this.btnSoma.Size = new System.Drawing.Size(75, 23);
            this.btnSoma.TabIndex = 7;
            this.btnSoma.Text = "Soma";
            this.btnSoma.UseVisualStyleBackColor = true;
            this.btnSoma.Click += new System.EventHandler(this.btnSoma_Click);
            // 
            // btnMedia
            // 
            this.btnMedia.Location = new System.Drawing.Point(159, 265);
            this.btnMedia.Name = "btnMedia";
            this.btnMedia.Size = new System.Drawing.Size(75, 23);
            this.btnMedia.TabIndex = 8;
            this.btnMedia.Text = "Media";
            this.btnMedia.UseVisualStyleBackColor = true;
            this.btnMedia.Click += new System.EventHandler(this.btnMedia_Click);
            // 
            // btnPorcentagem
            // 
            this.btnPorcentagem.Location = new System.Drawing.Point(257, 265);
            this.btnPorcentagem.Name = "btnPorcentagem";
            this.btnPorcentagem.Size = new System.Drawing.Size(79, 23);
            this.btnPorcentagem.TabIndex = 9;
            this.btnPorcentagem.Text = "Porcentagem";
            this.btnPorcentagem.UseVisualStyleBackColor = true;
            this.btnPorcentagem.Click += new System.EventHandler(this.btnPorcentagem_Click);
            // 
            // btnLimpar
            // 
            this.btnLimpar.Location = new System.Drawing.Point(363, 265);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(75, 23);
            this.btnLimpar.TabIndex = 10;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // lblResp1
            // 
            this.lblResp1.AutoSize = true;
            this.lblResp1.Location = new System.Drawing.Point(240, 107);
            this.lblResp1.Name = "lblResp1";
            this.lblResp1.Size = new System.Drawing.Size(0, 13);
            this.lblResp1.TabIndex = 11;
            // 
            // lblResp2
            // 
            this.lblResp2.AutoSize = true;
            this.lblResp2.Location = new System.Drawing.Point(240, 162);
            this.lblResp2.Name = "lblResp2";
            this.lblResp2.Size = new System.Drawing.Size(0, 13);
            this.lblResp2.TabIndex = 12;
            // 
            // lblResp3
            // 
            this.lblResp3.AutoSize = true;
            this.lblResp3.Location = new System.Drawing.Point(240, 217);
            this.lblResp3.Name = "lblResp3";
            this.lblResp3.Size = new System.Drawing.Size(0, 13);
            this.lblResp3.TabIndex = 13;
            // 
            // FrmExercicio01
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(255)))), ((int)(((byte)(217)))));
            this.ClientSize = new System.Drawing.Size(555, 314);
            this.Controls.Add(this.lblResp3);
            this.Controls.Add(this.lblResp2);
            this.Controls.Add(this.lblResp1);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.btnPorcentagem);
            this.Controls.Add(this.btnMedia);
            this.Controls.Add(this.btnSoma);
            this.Controls.Add(this.lblExercicio);
            this.Controls.Add(this.lblnum3);
            this.Controls.Add(this.lblnum2);
            this.Controls.Add(this.lblnum1);
            this.Controls.Add(this.txtnum3);
            this.Controls.Add(this.txtnum2);
            this.Controls.Add(this.txtnum1);
            this.Name = "FrmExercicio01";
            this.Text = "Exercicio01";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtnum1;
        private System.Windows.Forms.TextBox txtnum2;
        private System.Windows.Forms.TextBox txtnum3;
        private System.Windows.Forms.Label lblnum1;
        private System.Windows.Forms.Label lblnum2;
        private System.Windows.Forms.Label lblnum3;
        private System.Windows.Forms.Label lblExercicio;
        private System.Windows.Forms.Button btnSoma;
        private System.Windows.Forms.Button btnMedia;
        private System.Windows.Forms.Button btnPorcentagem;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.Label lblResp1;
        private System.Windows.Forms.Label lblResp2;
        private System.Windows.Forms.Label lblResp3;
    }
}

