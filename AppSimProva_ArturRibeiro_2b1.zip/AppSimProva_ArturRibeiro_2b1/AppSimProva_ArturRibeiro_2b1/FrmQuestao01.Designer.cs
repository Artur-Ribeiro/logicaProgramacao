﻿namespace AppSimProva_ArturRibeiro_2b1
{
    partial class FrmQuestao01
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmQuestao01));
            this.txtProduto1 = new System.Windows.Forms.TextBox();
            this.txtProduto2 = new System.Windows.Forms.TextBox();
            this.txtProduto3 = new System.Windows.Forms.TextBox();
            this.lblProduto1 = new System.Windows.Forms.Label();
            this.lblProduto2 = new System.Windows.Forms.Label();
            this.lblProduto3 = new System.Windows.Forms.Label();
            this.pnl1 = new System.Windows.Forms.Panel();
            this.btnCalc = new System.Windows.Forms.Button();
            this.lblPreco3 = new System.Windows.Forms.Label();
            this.lblPreco1 = new System.Windows.Forms.Label();
            this.lblPreco2 = new System.Windows.Forms.Label();
            this.txtPreco1 = new System.Windows.Forms.TextBox();
            this.txtPreco3 = new System.Windows.Forms.TextBox();
            this.txtPreco2 = new System.Windows.Forms.TextBox();
            this.pnl2 = new System.Windows.Forms.Panel();
            this.lblParcela5 = new System.Windows.Forms.Label();
            this.lblParcela4 = new System.Windows.Forms.Label();
            this.lblParcela3 = new System.Windows.Forms.Label();
            this.lblParcela2 = new System.Windows.Forms.Label();
            this.lblParcela1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.pnl1.SuspendLayout();
            this.pnl2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtProduto1
            // 
            this.txtProduto1.Location = new System.Drawing.Point(32, 58);
            this.txtProduto1.Name = "txtProduto1";
            this.txtProduto1.Size = new System.Drawing.Size(117, 20);
            this.txtProduto1.TabIndex = 0;
            // 
            // txtProduto2
            // 
            this.txtProduto2.Location = new System.Drawing.Point(32, 125);
            this.txtProduto2.Name = "txtProduto2";
            this.txtProduto2.Size = new System.Drawing.Size(117, 20);
            this.txtProduto2.TabIndex = 1;
            // 
            // txtProduto3
            // 
            this.txtProduto3.Location = new System.Drawing.Point(32, 193);
            this.txtProduto3.Name = "txtProduto3";
            this.txtProduto3.Size = new System.Drawing.Size(117, 20);
            this.txtProduto3.TabIndex = 2;
            // 
            // lblProduto1
            // 
            this.lblProduto1.AutoSize = true;
            this.lblProduto1.Location = new System.Drawing.Point(29, 42);
            this.lblProduto1.Name = "lblProduto1";
            this.lblProduto1.Size = new System.Drawing.Size(50, 13);
            this.lblProduto1.TabIndex = 3;
            this.lblProduto1.Text = "Produto1";
            // 
            // lblProduto2
            // 
            this.lblProduto2.AutoSize = true;
            this.lblProduto2.Location = new System.Drawing.Point(29, 109);
            this.lblProduto2.Name = "lblProduto2";
            this.lblProduto2.Size = new System.Drawing.Size(50, 13);
            this.lblProduto2.TabIndex = 4;
            this.lblProduto2.Text = "Produto2";
            // 
            // lblProduto3
            // 
            this.lblProduto3.AutoSize = true;
            this.lblProduto3.Location = new System.Drawing.Point(29, 177);
            this.lblProduto3.Name = "lblProduto3";
            this.lblProduto3.Size = new System.Drawing.Size(50, 13);
            this.lblProduto3.TabIndex = 5;
            this.lblProduto3.Text = "Produto3";
            // 
            // pnl1
            // 
            this.pnl1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pnl1.Controls.Add(this.btnCalc);
            this.pnl1.Controls.Add(this.lblPreco3);
            this.pnl1.Controls.Add(this.lblPreco1);
            this.pnl1.Controls.Add(this.lblPreco2);
            this.pnl1.Controls.Add(this.txtPreco1);
            this.pnl1.Controls.Add(this.txtPreco3);
            this.pnl1.Controls.Add(this.txtPreco2);
            this.pnl1.Controls.Add(this.lblProduto3);
            this.pnl1.Controls.Add(this.lblProduto1);
            this.pnl1.Controls.Add(this.lblProduto2);
            this.pnl1.Controls.Add(this.txtProduto1);
            this.pnl1.Controls.Add(this.txtProduto3);
            this.pnl1.Controls.Add(this.txtProduto2);
            this.pnl1.Location = new System.Drawing.Point(12, 86);
            this.pnl1.Name = "pnl1";
            this.pnl1.Size = new System.Drawing.Size(339, 291);
            this.pnl1.TabIndex = 6;
            // 
            // btnCalc
            // 
            this.btnCalc.BackColor = System.Drawing.Color.Lime;
            this.btnCalc.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalc.ForeColor = System.Drawing.Color.White;
            this.btnCalc.Location = new System.Drawing.Point(32, 243);
            this.btnCalc.Name = "btnCalc";
            this.btnCalc.Size = new System.Drawing.Size(101, 33);
            this.btnCalc.TabIndex = 12;
            this.btnCalc.Text = "Calcular";
            this.btnCalc.UseVisualStyleBackColor = false;
            this.btnCalc.Click += new System.EventHandler(this.btnCalc_Click);
            // 
            // lblPreco3
            // 
            this.lblPreco3.AutoSize = true;
            this.lblPreco3.Location = new System.Drawing.Point(174, 177);
            this.lblPreco3.Name = "lblPreco3";
            this.lblPreco3.Size = new System.Drawing.Size(41, 13);
            this.lblPreco3.TabIndex = 11;
            this.lblPreco3.Text = "Preço3";
            // 
            // lblPreco1
            // 
            this.lblPreco1.AutoSize = true;
            this.lblPreco1.Location = new System.Drawing.Point(174, 42);
            this.lblPreco1.Name = "lblPreco1";
            this.lblPreco1.Size = new System.Drawing.Size(41, 13);
            this.lblPreco1.TabIndex = 9;
            this.lblPreco1.Text = "Preço1";
            // 
            // lblPreco2
            // 
            this.lblPreco2.AutoSize = true;
            this.lblPreco2.Location = new System.Drawing.Point(174, 109);
            this.lblPreco2.Name = "lblPreco2";
            this.lblPreco2.Size = new System.Drawing.Size(41, 13);
            this.lblPreco2.TabIndex = 10;
            this.lblPreco2.Text = "Preço2";
            // 
            // txtPreco1
            // 
            this.txtPreco1.Location = new System.Drawing.Point(177, 58);
            this.txtPreco1.Name = "txtPreco1";
            this.txtPreco1.Size = new System.Drawing.Size(117, 20);
            this.txtPreco1.TabIndex = 6;
            // 
            // txtPreco3
            // 
            this.txtPreco3.Location = new System.Drawing.Point(177, 193);
            this.txtPreco3.Name = "txtPreco3";
            this.txtPreco3.Size = new System.Drawing.Size(117, 20);
            this.txtPreco3.TabIndex = 8;
            // 
            // txtPreco2
            // 
            this.txtPreco2.Location = new System.Drawing.Point(177, 125);
            this.txtPreco2.Name = "txtPreco2";
            this.txtPreco2.Size = new System.Drawing.Size(117, 20);
            this.txtPreco2.TabIndex = 7;
            // 
            // pnl2
            // 
            this.pnl2.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.pnl2.Controls.Add(this.lblParcela5);
            this.pnl2.Controls.Add(this.lblParcela4);
            this.pnl2.Controls.Add(this.lblParcela3);
            this.pnl2.Controls.Add(this.lblParcela2);
            this.pnl2.Controls.Add(this.lblParcela1);
            this.pnl2.Location = new System.Drawing.Point(361, 86);
            this.pnl2.Name = "pnl2";
            this.pnl2.Size = new System.Drawing.Size(289, 290);
            this.pnl2.TabIndex = 7;
            // 
            // lblParcela5
            // 
            this.lblParcela5.AutoSize = true;
            this.lblParcela5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblParcela5.ForeColor = System.Drawing.Color.White;
            this.lblParcela5.Location = new System.Drawing.Point(67, 191);
            this.lblParcela5.Name = "lblParcela5";
            this.lblParcela5.Size = new System.Drawing.Size(109, 20);
            this.lblParcela5.TabIndex = 4;
            this.lblParcela5.Text = "5 Parcelas de:";
            // 
            // lblParcela4
            // 
            this.lblParcela4.AutoSize = true;
            this.lblParcela4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblParcela4.ForeColor = System.Drawing.Color.White;
            this.lblParcela4.Location = new System.Drawing.Point(67, 157);
            this.lblParcela4.Name = "lblParcela4";
            this.lblParcela4.Size = new System.Drawing.Size(109, 20);
            this.lblParcela4.TabIndex = 3;
            this.lblParcela4.Text = "4 Parcelas de:";
            // 
            // lblParcela3
            // 
            this.lblParcela3.AutoSize = true;
            this.lblParcela3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblParcela3.ForeColor = System.Drawing.Color.White;
            this.lblParcela3.Location = new System.Drawing.Point(67, 125);
            this.lblParcela3.Name = "lblParcela3";
            this.lblParcela3.Size = new System.Drawing.Size(109, 20);
            this.lblParcela3.TabIndex = 2;
            this.lblParcela3.Text = "3 Parcelas de:";
            // 
            // lblParcela2
            // 
            this.lblParcela2.AutoSize = true;
            this.lblParcela2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblParcela2.ForeColor = System.Drawing.Color.White;
            this.lblParcela2.Location = new System.Drawing.Point(67, 90);
            this.lblParcela2.Name = "lblParcela2";
            this.lblParcela2.Size = new System.Drawing.Size(109, 20);
            this.lblParcela2.TabIndex = 1;
            this.lblParcela2.Text = "2 Parcelas de:";
            // 
            // lblParcela1
            // 
            this.lblParcela1.AutoSize = true;
            this.lblParcela1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblParcela1.ForeColor = System.Drawing.Color.White;
            this.lblParcela1.Location = new System.Drawing.Point(67, 58);
            this.lblParcela1.Name = "lblParcela1";
            this.lblParcela1.Size = new System.Drawing.Size(101, 20);
            this.lblParcela1.TabIndex = 0;
            this.lblParcela1.Text = "1 Parcela de:";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Red;
            this.panel1.Controls.Add(this.lblTitulo);
            this.panel1.Location = new System.Drawing.Point(8, 9);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(642, 68);
            this.panel1.TabIndex = 8;
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Segoe Print", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.Location = new System.Drawing.Point(25, 7);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(287, 61);
            this.lblTitulo.TabIndex = 0;
            this.lblTitulo.Text = "Loja de Games";
            // 
            // FrmQuestao01
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(658, 388);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pnl2);
            this.Controls.Add(this.pnl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmQuestao01";
            this.Text = "Games";
            this.pnl1.ResumeLayout(false);
            this.pnl1.PerformLayout();
            this.pnl2.ResumeLayout(false);
            this.pnl2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox txtProduto1;
        private System.Windows.Forms.TextBox txtProduto2;
        private System.Windows.Forms.TextBox txtProduto3;
        private System.Windows.Forms.Label lblProduto1;
        private System.Windows.Forms.Label lblProduto2;
        private System.Windows.Forms.Label lblProduto3;
        private System.Windows.Forms.Panel pnl1;
        private System.Windows.Forms.Label lblPreco3;
        private System.Windows.Forms.Label lblPreco1;
        private System.Windows.Forms.Label lblPreco2;
        private System.Windows.Forms.TextBox txtPreco1;
        private System.Windows.Forms.TextBox txtPreco3;
        private System.Windows.Forms.TextBox txtPreco2;
        private System.Windows.Forms.Button btnCalc;
        private System.Windows.Forms.Panel pnl2;
        private System.Windows.Forms.Label lblParcela5;
        private System.Windows.Forms.Label lblParcela4;
        private System.Windows.Forms.Label lblParcela3;
        private System.Windows.Forms.Label lblParcela2;
        private System.Windows.Forms.Label lblParcela1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblTitulo;
    }
}

