﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppSimProva_ArturRibeiro_2b1
{
    public partial class FrmQuestao01 : Form
    {
        public FrmQuestao01()
        {
            InitializeComponent();
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            float preco1 = float.Parse (txtPreco1.Text);
            float preco2 = float.Parse(txtPreco2.Text);
            float preco3 = float.Parse(txtPreco3.Text);
            float result;

            result = preco1 + preco2 + preco3;

            lblParcela1.Text = ("1 Parcela de: " + result.ToString("C"));

            lblParcela2.Text = ("2 Parcelas de: " + (result/2).ToString("C"));

            lblParcela3.Text = ("3 Parcelas de: " + (result / 3).ToString("C"));

            lblParcela4.Text = ("4 Parcelas de: " + (result / 4).ToString("C"));

            lblParcela5.Text = ("5 Parcelas de: " + (result / 5).ToString("C"));
        }

    }
}
