﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppSimProva_ArturRibeiro_2b1
{
    public partial class FrmQuestao03 : Form
    {
        public FrmQuestao03()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            float valor = float.Parse (txtValor.Text);
            float desconto;

            lblValor.Text = valor.ToString("C");

            desconto = valor * 0.88f;
            lblDesconto.Text = desconto.ToString("C");
        }
    }
}
