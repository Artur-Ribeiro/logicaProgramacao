﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppSimProva_ArturRibeiro_2b1
{
    public partial class FrmQuestao02 : Form
    {
        public FrmQuestao02()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            float preco = float.Parse (txtPreco.Text);
            float inicial;
            float parcela;

            inicial = preco * 0.4f;
            lblInicial.Text = ("Pagamento Inicial: " + inicial.ToString("C"));

            parcela = (preco * 0.6f) / 3;
            lblParcelas.Text = ("3 Parcelas de: " + parcela.ToString("C"));
        }
    }
}
