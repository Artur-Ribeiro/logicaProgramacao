﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto_calc
{
    public partial class Frmcalc : Form
    {
        public Frmcalc()
        {
            InitializeComponent();
        }

        private void bntCalcular_Click(object sender, EventArgs e)
        {
       
                float num1 = float.Parse(txtNum1.Text);
                float num2 = float.Parse(txtNum2.Text);
                float resultado;

                //Soma
                resultado = num1 + num2;
                lblSoma.Text = ("soma: " + resultado);

                //Subtração
                resultado = num1 - num2;
                lblSub.Text = ("subtração: " + resultado);

                //Divisão
                resultado = num1 / num2;
                lblDiv.Text = ("divisão: " + resultado);

                //Multiplicação
                resultado = num1 * num2;
                lblMult.Text = ("multiplicação: " + resultado);

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lblSoma.Text = String.Empty;
            lblSub.Text = String.Empty;
            lblDiv.Text = String.Empty;
            lblMult.Text = String.Empty;
            txtNum1.Text = String.Empty;
            txtNum2.Text = String.Empty;
        }
    }
}
